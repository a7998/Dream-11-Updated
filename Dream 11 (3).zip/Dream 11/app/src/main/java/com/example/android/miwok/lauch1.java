package com.example.ListDisplay;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class secondActivity extends AppCompatActivity
{
  ArrayList<Word1> first=new ArrayList<Word1>();

    first.add(new first(R.drawable.imgp1,"Player1",R.drawable.img2));
    first.add(new first(R.drawable.imgp2,"Player2",R.drawable.img3));
    first.add(new first(R.drawable.imgp3,"Player2",R.drawable.img5));
    first.add(new first(R.drawable.imgp4,"Player3",R.drawable.img7));
    first.add(new first(R.drawable.imgp5,"Player4",R.drawable.img9));
    first.add(new first(R.drawable.imgp6,"Player5",R.drawable.img11));
@Override
   protected void onCreate(Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
      setContentView(R.layout.activity_main);
      
      ArrayAdapter adapter1 = new ArrayAdapter<Word1>(this, 
         R.layout.list1,first);
      
      ListView listView = (ListView) findViewById(R.id.list1);
      listView.setAdapter(adapter1);

}
}

