package com.example.ListDisplay;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class launch5 extends AppCompatActivity
{
  ArrayList<Word1> first=new ArrayList<Word1>();

    first.add(new first(R.drawable.imgp7,"Player1",R.drawable.img211));
    first.add(new first(R.drawable.imgp8,"Player2",R.drawable.img322));
    first.add(new first(R.drawable.imgp9,"Player2",R.drawable.img533));
    first.add(new first(R.drawable.imgp10,"Player3",R.drawable.img755));
    first.add(new first(R.drawable.imgp11,"Player4",R.drawable.img951));
    first.add(new first(R.drawable.imgp12,"Player5",R.drawable.img1111));
@Override
   protected void onCreate(Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
      setContentView(R.layout.activity_main);
      
      ArrayAdapter adapter2 = new ArrayAdapter<Word1>(this, 
         R.layout.list1,first);
      
      ListView listView = (ListView) findViewById(R.id.list1);
      listView.setAdapter(adapter2);

}
}

